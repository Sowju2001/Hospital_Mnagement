﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Hospitalmng
{
    public partial class adminward : System.Web.UI.Page
    {
        connect c;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ShowData();
            }
            Panel1.Visible = false;
            Panel2.Visible = false;
            Panel3.Visible = false;


        }
        protected void ShowData()
        {
            c = new connect();
            c.cnn.Close();
            c.cnn.Open();
            string query = "select * from ward";
            SqlDataAdapter adp = new SqlDataAdapter(query, c.cnn);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }





        protected void btnview_Click(object sender, EventArgs e)
        {
            ShowData();
        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            Panel1.Visible = true;
        }



        protected void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                c = new connect();
                if (c.cnn.State == System.Data.ConnectionState.Closed)
                {
                    c.cnn.Open();
                }
                c.cmd.Parameters.Clear();
                c.cmd.CommandText = "insert into ward values(@beds,@status)";
                c.cmd.Parameters.AddWithValue("@beds", txtnewid.Text);
                c.cmd.Parameters.AddWithValue("@status", txtstatus.Text);
                c.cmd.ExecuteNonQuery();
                MessageBox.Show("Sucessfully Added");
                c.cnn.Close();


            }
            catch (Exception ex)
            {
                MessageBoxButtons btn = new MessageBoxButtons();
                MessageBox.Show(ex.ToString(), "", btn, MessageBoxIcon.Error);
            }
            txtnewid.Text = "";
            txtstatus.Text = "";
        }



        protected void btnupdate_Click(object sender, EventArgs e)
        {
            Panel2.Visible = true;
        }

        protected void btndelete_Click(object sender, EventArgs e)
        {
            Panel3.Visible = true;
        }

        protected void btnyes_Click(object sender, EventArgs e)
        {
            c = new connect();
            c.cnn.Close();
            c.cnn.Open();

            c.cmd.CommandText = "Delete from ward where beds='" + TextBox3.Text + "'";
            c.cmd.ExecuteNonQuery();
            MessageBox.Show("Deleted successfully");
            c.cnn.Close();
            TextBox3.Text = "";
        }



        protected void btnok_Click1(object sender, EventArgs e)
        {

            c = new connect();
            c.cmd.Parameters.Clear();
            c.cmd.CommandText = "Update ward SET status='" + TextBox2.Text + "' where beds='" + TextBox1.Text + "'";
            c.cmd.ExecuteNonQuery();
            MessageBox.Show("updated sucessfully");
            c.cnn.Close();
            TextBox2.Text = "";
            TextBox1.Text = "";

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("home.aspx");
        }
    }
}
