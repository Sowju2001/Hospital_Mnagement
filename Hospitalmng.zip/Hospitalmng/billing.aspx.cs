﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace Hospitalmng
{
    public partial class billing : System.Web.UI.Page
    {



        connect c;
        SqlDataReader rdr;
        DataSet ds;
        SqlDataAdapter adp;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //  Calendar1.Visible = false;
                // Calendar2.Visible = false;
                Panel1.Visible = false;
                Panel2.Visible = false;
            }
        }




        // protected void Calendar1_DayRender(object sender, DayRenderEventArgs e)
        //{
        //  if (e.Day.IsOtherMonth)
        //{
        //  e.Day.IsSelectable = false;
        // e.Cell.BackColor = System.Drawing.Color.Aquamarine;


        //}
        // }





        //protected void Calendar2_DayRender(object sender, DayRenderEventArgs e)
        //{
        //  if (e.Day.IsOtherMonth)
        //{
        //  e.Day.IsSelectable = false;

        //}
        //}

        //protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        //{

        //}

        //protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        //{

        // if (Calendar1.Visible)
        //{
        //   Calendar1.Visible = false;
        //  }
        // else
        // {
        //  Calendar1.Visible = true;
        // }
        // Calendar1.Attributes.Add("style", "position:absolute");


        //}

        // protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
        // {

        // }



        protected void button1_Click1(object sender, EventArgs e)
        {
           


            if (RadioButtonList1.SelectedValue == "1")
            {
                Panel1.Visible = true;
                

            }
           else 
            {
                Panel2.Visible = true;
                txtout1.Text = DateTime.Now.ToString("dd/MM/yyyy");
                txtout2.Text = "150";
                connect c = new connect();
                c.cnn.Close();
                c.cnn.Open();
                c.cmd.CommandText = "Select total from outpatient where regno='" + txt1.Text + "'";
                rdr = c.cmd.ExecuteReader();
                while (rdr.Read())
                {
                    txtout3.Text = rdr["total"].ToString();
                }

                txtout4.Text = "400"; 


            }



        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            c = new connect();
            c.cnn.Close();
            c.cnn.Open();
            c.cmd.CommandText = "Select name,pno,addr from inpatient where regno='" + txt1.Text + "'";
            rdr = c.cmd.ExecuteReader();
            bool temp = false;
            while (rdr.Read())
            {
                txt2.Text = Convert.ToString(rdr["name"]);
                txt3.Text = rdr["pno"].ToString();
                txt4.Text = rdr["addr"].ToString();


                temp = true;

            }
            if (temp == false)
            {
                Response.Write("<script>alert('Not Found')</alert>");
                c.cnn.Close();
            }
            rdr.Close();
            ds = new DataSet();
            adp = new SqlDataAdapter("Select * from inpatient", c.cnn);
            adp.Fill(ds, "Table2");
            c.cnn.Close();

        }

        protected void btnoutbill_Click(object sender, EventArgs e)
        {
            Response.Redirect("outpatientbill.aspx");
        }
    }
}

        //protected void Calendar1_SelectionChanged1(object sender, EventArgs e)
      //  {
            //txt6.Text = Calendar1.SelectedDate.ToString("dd/MM/yyyy");
          //  Calendar1.Visible = false;
        //}

        //protected void Calendar2_SelectionChanged1(object sender, EventArgs e)
        //{
            //txt7.Text = Calendar2.SelectedDate.ToString("dd/MM/yyyy");
          //  Calendar2.Visible = false;

        //}

        //protected void ImageButton2_Click1(object sender, ImageClickEventArgs e)
        //{
            //if (Calendar2.Visible)
            //{
              //  Calendar2.Visible = false;
            //}
            //else
          //  {
                //Calendar2.Visible = true;
           // }
           // Calendar2.Attributes.Add("style", "position:absolute");

       // }
    
