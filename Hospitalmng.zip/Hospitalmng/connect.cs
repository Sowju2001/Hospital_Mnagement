﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI.WebControls;




namespace Hospitalmng
{
    public class connect
    {
        public SqlConnection cnn = new SqlConnection();
        public SqlCommand cmd = new SqlCommand();
        public connect()
        {
            cnn.ConnectionString = "Data Source=DESKTOP-U97KSKI\\SQLEXPRESS;Initial Catalog=hospitalmng;Integrated Security=true";
            cnn.Open();
            cmd.Connection = cnn;

        }




    }
}