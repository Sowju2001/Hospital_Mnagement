﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace Hospitalmng
{
    public partial class newbill : System.Web.UI.Page
    {
        connect c;
    
        DataSet ds;

        protected void Page_Load(object sender, EventArgs e)
        {
            Panel2.Visible = false;
            Panel3.Visible = false;
            Session["regno"] = txtregister.Text;

        }

        protected void btnsub_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            c = new connect();
            c.cnn.Close();
            c.cnn.Open();
            SqlDataReader rdr;
            Label1.Text = (string)(Session["regno"]);


            if (RadioButtonList1.SelectedValue == "1")
            {
                Panel2.Visible = true;
                
                 c = new connect();
                // Label1.Text = txtregister.ToString ();
                
                txtn.Text = txtname.Text;
                c.cnn.Close();
                c.cnn.Open();
             
                //lbldis.Text = DateTime.Now.ToString("dd/MM/yyyy");
                txtconsult.Text = "150";
                
                c.cnn.Close();
                c.cnn.Open();
                c.cmd.CommandText = "Select total from inpatient where regno='" + txtregister.Text + "'";
                rdr = c.cmd.ExecuteReader();
                while (rdr.Read())
                {
                   // Label1.Text = rdr["regno"].ToString();
                    txtlab.Text = rdr["total"].ToString();
                }

               txtmedi.Text = "400";


            }



     
            else
            {
                Panel3.Visible = true;
            }   
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            c = new connect();
            c.cnn.Close();
            c.cnn.Open();
            SqlDataReader rdr;
            SqlDataAdapter adp;
            c.cmd.CommandText = "Select name,pno,addr from inpatient where regno='" + txtregister.Text + "'";
            rdr = c.cmd.ExecuteReader();
            bool temp = false;
           

            while (rdr.Read())
            {
                txtname.Text = Convert.ToString(rdr["name"]);
                txtnumber.Text = rdr["pno"].ToString();
                txtaddr.Text = rdr["addr"].ToString();


                temp = true;

            }
            if (temp == false)
            {
                Response.Write("<script>alert('Not Found')</alert>");
                c.cnn.Close();
            }
            rdr.Close();
            ds = new DataSet();
            adp = new SqlDataAdapter("Select * from inpatient", c.cnn);
            adp.Fill(ds, "Table2");
            c.cnn.Close();


        }

       
    }
       
}