﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace Hospitalmng
{
    public partial class inbill2 : System.Web.UI.Page
    {
        connect c;
        SqlDataReader rdr;
        DataSet ds;
        SqlDataAdapter da;
        protected void Page_Load(object sender, EventArgs e)
        {
           
        
        
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            c = new connect();
            c.cnn.Close();
            c.cnn.Open();
            c.cmd.CommandText = "Select patno,name,total from inpatient where regno='" + txtno.Text + "'";
            rdr = c.cmd.ExecuteReader();
            bool temp = false;
            while (rdr.Read())
            {
                lblpid.Text = rdr["patno"].ToString();
                lblname.Text = rdr["name"].ToString();
                lbllab.Text = rdr["total"].ToString();
                temp = true;

            }
            if (temp == false)
            {
                Response.Write("<script>alert('Not Found')</script>");
                c.cnn.Close();
            }
            rdr.Close();
            ds = new DataSet();
            da = new SqlDataAdapter("Select * from inpatient", c.cnn);
            da.Fill(ds, "Table2");
            c.cnn.Close();
            Label10.Text = (int.Parse(lblconsult.Text) + int.Parse(lblmed.Text) + int.Parse(lblbed.Text) + int.Parse(lbllab.Text)).ToString();

        }

    }
    
}