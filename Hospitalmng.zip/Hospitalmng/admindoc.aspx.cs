﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Hospitalmng
{
    public partial class admindoc : System.Web.UI.Page
    {
        connect c;
        DataSet ds;
        SqlDataAdapter adp = new SqlDataAdapter();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ShowData();
            }
            Panel1.Visible = false;
            Panel2.Visible = false;
            Panel3.Visible = false;



        }
        protected void ShowData()
        {
            c = new connect();
            c.cnn.Close();
            c.cnn.Open();
            string query = "select * from doctor";
            SqlDataAdapter adp = new SqlDataAdapter(query, c.cnn);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

        protected void docview_Click(object sender, EventArgs e)
        {
            ShowData();
        }
        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            c = new connect();
            try
            {
                c = new connect();
                if (c.cnn.State == System.Data.ConnectionState.Closed)
                {
                    c.cnn.Open();
                }
                c.cmd.Parameters.Clear();
                c.cmd.CommandText = "insert into doctor values(@docid,@docname,@docno,@specialisation,@status)";
                c.cmd.Parameters.AddWithValue("@docid", txtid.Text);
                c.cmd.Parameters.AddWithValue("@docname", Txtdocname.Text);
                c.cmd.Parameters.AddWithValue("@docno", txtnumber.Text);
                c.cmd.Parameters.AddWithValue("@specialisation", txtspcl.Text);
                c.cmd.Parameters.AddWithValue("status", txtst.Text);
                c.cmd.ExecuteNonQuery();
                MessageBox.Show("Sucessfully Added");
                c.cnn.Close();


            }
            catch (Exception ex)
            {
                MessageBoxButtons btn = new MessageBoxButtons();
                MessageBox.Show(ex.ToString(), "", btn, MessageBoxIcon.Error);
            }
            txtid.Text = "";
            Txtdocname.Text = "";
            txtnumber.Text = "";
            txtspcl.Text = "";
            txtst.Text = "";
        }

        protected void docdel_Click(object sender, EventArgs e)
        {
            Panel2.Visible = true;
        }

        protected void btok_Click(object sender, EventArgs e)
        {
            c = new connect();
            c.cnn.Close();
            c.cnn.Open();

            c.cmd.CommandText = "Select * from doctor where docid='" + TextBox1.Text + "'";
            ds = new DataSet();
            adp.SelectCommand = c.cmd;
            adp.Fill(ds, "log");
            if (ds.Tables["log"].Rows.Count > 0)
            {
                c.cmd.CommandText = "Delete from doctor where docid='" + TextBox1.Text + "'";
                c.cmd.ExecuteNonQuery();
                c.cnn.Close();



            }
            else
            {
                MessageBox.Show("Invalid id");
            }
            TextBox1.Text = "";
        }

        protected void docadd_Click(object sender, EventArgs e)
        {
            Panel1.Visible = true;
        }

        protected void btndocupdate_Click(object sender, EventArgs e)
        {
            Panel3.Visible = true;
        }

        protected void btnup_Click(object sender, EventArgs e)
        {
            c = new connect();
            c.cmd.Parameters.Clear();
            c.cmd.CommandText = "Update doctor SET status='" + txts.Text + "' where docid='" + txti.Text + "'";
            c.cmd.ExecuteNonQuery();
            MessageBox.Show("updated sucessfully");
            c.cnn.Close();
            txts.Text = "";
            txti.Text = "";

        }

        protected void txts_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("adminhome.aspx");
        }
    }
}





    
