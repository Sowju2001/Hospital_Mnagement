﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace Hospitalmng
{
    public partial class staffview : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            GridView1.DataBind();

        }

      protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            GridView1.DataSource = SqlDataSource1;
            GridView1.DataBind();
            Label13.Text = "";
            GridView1.EditRowStyle.BackColor = System.Drawing.Color.Orange;



        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            GridView1.DataSource = SqlDataSource1;
            GridView1.DataBind();
            Label13.Text = "";
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            Label regno = GridView1.Rows[e.RowIndex].FindControl("Lable11") as Label;
            Label patno = GridView1.Rows[e.RowIndex].FindControl("Lable12") as Label;
            TextBox name = GridView1.Rows[e.RowIndex].FindControl("TextBox1") as TextBox;
            TextBox dob = GridView1.Rows[e.RowIndex].FindControl("TextBox2") as TextBox;
            TextBox age = GridView1.Rows[e.RowIndex].FindControl("TextBox3") as TextBox;
            TextBox pno = GridView1.Rows[e.RowIndex].FindControl("TextBox4") as TextBox;
            TextBox gender = GridView1.Rows[e.RowIndex].FindControl("TextBox5") as TextBox;
            TextBox beds = GridView1.Rows[e.RowIndex].FindControl("TextBox6") as TextBox;
            TextBox labtest = GridView1.Rows[e.RowIndex].FindControl("TextBox7") as TextBox;
            TextBox addr = GridView1.Rows[e.RowIndex].FindControl("TextBox8") as TextBox;
            String mycon= "Data Source=DESKTOP-U97KSKI\\SQLEXPRESS; Initial Catalog=hospitalmng; Integrated Security=True";
            //String updatedata="update inpatient set regno='"+ txt//
            SqlConnection con = new SqlConnection(mycon);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            // cmd.CommandText = updatedata;//
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            Label13.Text = "Row Data has been updated successfully";
            GridView1.EditIndex = -1;
            SqlDataSource1.DataBind();
            GridView1.DataSource = SqlDataSource1;
            GridView1.DataBind();





        }

        protected void LinkButton5_Click(object sender, EventArgs e)
        {
            TextBox regno = GridView1.FooterRow.FindControl("TextBox9") as TextBox;
            TextBox patno = GridView1.FooterRow.FindControl("TextBox10") as TextBox;
            TextBox name = GridView1.FooterRow.FindControl("TextBox11") as TextBox;
            TextBox dob = GridView1.FooterRow.FindControl("TextBox12") as TextBox;
            TextBox age = GridView1.FooterRow.FindControl("TextBox13") as TextBox;
            TextBox pno = GridView1.FooterRow.FindControl("TextBox14") as TextBox;
            TextBox gender = GridView1.FooterRow.FindControl("TextBox15") as TextBox;
            TextBox beds = GridView1.FooterRow.FindControl("TextBox16") as TextBox;
            TextBox labtest = GridView1.FooterRow.FindControl("TextBox17") as TextBox;
            TextBox addr = GridView1.FooterRow.FindControl("TextBox18") as TextBox;
            //   String query="insert into set "//
            String mycon = "Data Source=DESKTOP-U97KSKI\\SQLEXPRESS; Initial Catalog=hospitalmng; Integrated Security=True";
            SqlConnection con = new SqlConnection(mycon);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            // cmd.CommandText = query;//
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            Label13.Text = "New row inserted successfully";
            SqlDataSource1.DataBind();
            GridView1.DataSource = SqlDataSource1;
            GridView1.DataBind();


        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            Label regno = GridView1.Rows[e.RowIndex].FindControl("Label1") as Label;
            String mycon = "Data Source=DESKTOP-U97KSKI\\SQLEXPRESS; Initial Catalog=hospitalmng; Integrated Security=True";
            String updatedata="Delete from inpatient where regno=" + regno.Text; 
            SqlConnection con = new SqlConnection(mycon);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = updatedata;
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            Label13.Text = "Row Data has been deleted successfully";
            GridView1.EditIndex = -1;
            SqlDataSource1.DataBind();
            GridView1.DataSource = SqlDataSource1;
            GridView1.DataBind();

        }
    }
}