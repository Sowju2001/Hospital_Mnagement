﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace Hospitalmng
{
    public partial class staffdocview : System.Web.UI.Page
    {
        connect c;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ShowData();
            }
           


        }
        protected void ShowData()
        {
            c = new connect();
            c.cnn.Close();
            c.cnn.Open();
            string query = "select * from doctor";
            SqlDataAdapter adp = new SqlDataAdapter(query, c.cnn);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
    }
}