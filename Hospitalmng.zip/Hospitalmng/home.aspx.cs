﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Hospitalmng
{
    public partial class home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

       

        protected void txtdoc_Click(object sender, EventArgs e)
        {
            Response.Redirect("staffdocview.aspx");
        }

        protected void txtreg_Click(object sender, EventArgs e)
        {
            Response.Redirect("register.aspx");
        }

        protected void txtview_Click(object sender, EventArgs e)
        {
            Response.Redirect("staffview2.aspx");
        }

   

        protected void txtbill_Click(object sender, EventArgs e)
        {
            Response.Redirect("billing2.aspx");
        }
    }
}