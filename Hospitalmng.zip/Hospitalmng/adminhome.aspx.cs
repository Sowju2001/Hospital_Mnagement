﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Hospitalmng
{
    public partial class adminhome : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void txtdoc_Click(object sender, EventArgs e)
        {
            Response.Redirect("admindoc.aspx");
        }

        protected void txtward_Click(object sender, EventArgs e)
        {
            Response.Redirect("adminward.aspx");
        }

        protected void txtpat_Click(object sender, EventArgs e)
        {
            Response.Redirect("adminpatient.aspx");
        }
    }
}