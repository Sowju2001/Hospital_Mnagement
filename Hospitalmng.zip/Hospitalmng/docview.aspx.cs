﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


namespace Hospitalmng
{
    public partial class docview : System.Web.UI.Page
    {
        connect c;

        DataSet ds = new DataSet();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                gvbind();
            }


        }
        protected void gvbind()
        {
            c = new connect();

            c.cnn.Close();
            c.cnn.Open();
            //  SqlCommand cmd = new SqlCommand("select * from registration", c.cnn);
            string query = "select regno,name,age,patienttype from registration";
            SqlDataAdapter adp = new SqlDataAdapter(query, c.cnn);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            GridView1.DataSource = dt;
            GridView1.DataBind();


        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            gvbind();
            c.cnn.Close();
            c.cnn.Open();
            String query = "select regno,name,age,patienttype from registration where regno like '%'+@regno+'%'";
            c.cmd.CommandText = query;
            c.cmd.Connection = c.cnn;
            c.cmd.Parameters.AddWithValue("regno", txtsearch.Text);
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(c.cmd);
            sda.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
            if (GridView1.Rows.Count == 0)
            {
                Response.Write("<script>alert('No Such Records Found')</script>");
            }
            txtsearch.Text = "";


        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("login.aspx");
        }

        
          



            protected void GridView1_RowEditing(object sender, System.Web.UI.WebControls.GridViewEditEventArgs e)
            {
                //NewEditIndex property used to determine the index of the row being edited.  
                GridView1.EditIndex = e.NewEditIndex;
                gvbind();
            }


            protected void GridView1_RowUpdating(object sender, System.Web.UI.WebControls.GridViewUpdateEventArgs e)
            {
                //Finding the controls from Gridview for the row which is going to update  
                Label Registerno = GridView1.Rows[e.RowIndex].FindControl("lbl_regno") as Label;

                TextBox Name = GridView1.Rows[e.RowIndex].FindControl("txt_name") as TextBox;
                //TextBox fname = GridView1.Rows[e.RowIndex].FindControl("txt_fname") as TextBox;
               // TextBox DOB = GridView1.Rows[e.RowIndex].FindControl("txt_dob") as TextBox;
                TextBox Age = GridView1.Rows[e.RowIndex].FindControl("txt_age") as TextBox;
               // TextBox Pno = GridView1.Rows[e.RowIndex].FindControl("txt_pno") as TextBox;
               // TextBox gender = GridView1.Rows[e.RowIndex].FindControl("txt_gender") as TextBox;
               // TextBox height = GridView1.Rows[e.RowIndex].FindControl("txt_hieght") as TextBox;
               // TextBox weight = GridView1.Rows[e.RowIndex].FindControl("txt_wieght") as TextBox;
               // TextBox addr = GridView1.Rows[e.RowIndex].FindControl("txt_addr") as TextBox;
                TextBox patienttype = GridView1.Rows[e.RowIndex].FindControl("txt_patienttype") as TextBox;
               // TextBox state = GridView1.Rows[e.RowIndex].FindControl("txt_state") as TextBox;
               // TextBox country = GridView1.Rows[e.RowIndex].FindControl("txt_country") as TextBox;


                c = new connect();
                c.cnn.Close();
                c.cnn.Open();
                //updating the record  
                c.cmd.Parameters.Clear();
                c.cmd.CommandText = "update registration SET name=@Name,age=@Age,patienttype=@patienttype where regno='" + Registerno.Text + "'";
                c.cmd.Parameters.AddWithValue("@regno", Convert.ToDouble(Registerno.Text));
                c.cmd.Parameters.AddWithValue("@Name", Name.Text);
               // c.cmd.Parameters.AddWithValue("@fname", fname.Text);
               // c.cmd.Parameters.AddWithValue("@DOB", Convert.ToDateTime(DOB.Text));
                c.cmd.Parameters.AddWithValue("@Age", Convert.ToDouble(Age.Text));
               // c.cmd.Parameters.AddWithValue("@Pno", Convert.ToDouble(Pno.Text));
               // c.cmd.Parameters.AddWithValue("@gender", Convert.ToString(gender.Text));
               // c.cmd.Parameters.AddWithValue("@height", height.Text);
               // c.cmd.Parameters.AddWithValue("@weight", weight.Text);
               // c.cmd.Parameters.AddWithValue("@addr", addr.Text);
                c.cmd.Parameters.AddWithValue("@patienttype", patienttype.Text);
               // c.cmd.Parameters.AddWithValue("@state", state.Text);
               // c.cmd.Parameters.AddWithValue("@country", country.Text);
                c.cmd.ExecuteNonQuery();
                Response.Write("<script>alert('updated sucessfully..')</script>");
                c.cnn.Close();

            }
            protected void GridView1_RowCancelingEdit(object sender, System.Web.UI.WebControls.GridViewCancelEditEventArgs e)
            {
                //Setting the EditIndex property to -1 to cancel the Edit mode in Gridview  
                GridView1.EditIndex = -1;
                gvbind();
            }
        }
    }





      