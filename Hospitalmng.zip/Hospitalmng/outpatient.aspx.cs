﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
namespace Hospitalmng
{
    public partial class outpatient : System.Web.UI.Page


    { 
            connect c;
            SqlDataAdapter adp = new SqlDataAdapter();
            DataSet ds= new DataSet();
            String id = "";
        SqlDataReader rdr;
            protected void Page_Load(object sender, EventArgs e)
            {
            lbltotal.Visible = false;
            txttotal.Visible = false;
            if (!IsPostBack)
            {
                GenerateAutoId();
            }


        }
        private void GenerateAutoId()
        {
            c = new connect();

            c.cmd.CommandText = "select count(outid) from outpatient";
            int i = Convert.ToInt32(c.cmd.ExecuteScalar());

            c.cnn.Close();
            i++;
            txtoutid.Text = id + i.ToString();

        }













        protected void btnupadd_Click1(object sender, EventArgs e)
            {
            int total = 0;
            for (int j = 0; j <= CheckBoxList1.Items.Count - 1; j++)
            {
                if (CheckBoxList1.Items[j].Selected)
                {
                    total += Convert.ToInt32(CheckBoxList1.Items[j].Value);
                }
            }
            txttotal.Text = total.ToString();
            try
                {
                    c = new connect();
                    if (c.cnn.State == System.Data.ConnectionState.Closed)
                    {
                        c.cnn.Open();

                    }
                    c.cmd.Parameters.Clear();
                    c.cmd.CommandText = "insert into outpatient values(@regno,@outid,@name,@dob,@age,@pno,@gender,@labtest,@total,@addr)";
                    c.cmd.Parameters.AddWithValue("@regno", Convert.ToDouble(txtreg.Text));
                c.cmd.Parameters.AddWithValue("@outid", Convert.ToDouble(txtoutid.Text));

                c.cmd.Parameters.AddWithValue("@name", txtname.Text);

                    c.cmd.Parameters.AddWithValue("@dob", Convert.ToDateTime(txtdob.Text));
                    c.cmd.Parameters.AddWithValue("@age", Convert.ToDouble(txtage.Text));
                    c.cmd.Parameters.AddWithValue("@pno", Convert.ToDouble(txtMobile.Text));
                    c.cmd.Parameters.AddWithValue("@gender", radiogender.SelectedItem.Value.ToString());
                 
                    c.cmd.Parameters.AddWithValue("@labtest", CheckBoxList1.Text);
                c.cmd.Parameters.AddWithValue("@total", Convert.ToDouble(txttotal.Text));


                c.cmd.Parameters.AddWithValue("@addr", txtaddr.Text);


                    c.cmd.ExecuteNonQuery();


                    MessageBox.Show("updated successfully......!");
                    c.cnn.Close();

                }
                catch (Exception ex)
                {
                    MessageBoxButtons btn = new MessageBoxButtons();
                    MessageBox.Show(ex.ToString(), "", btn, MessageBoxIcon.Error);

                }
                finally
                {
                    c.cnn.Close();
                }



            }

            protected void btncl_Click(object sender, EventArgs e)
            {
                txtreg.Text = "";
              
                txtname.Text = "";
                txtdob.Text = "";
                txtage.Text = "";
                txtMobile.Text = "";
            radiogender.ClearSelection();
            CheckBoxList1.ClearSelection();
         
                txtoutid.Text = "";
                txtaddr.Text = "";
            }

            protected void btnback_Click(object sender, EventArgs e)
            {
                Response.Redirect("register.aspx");
            }

        protected void txtdob_TextChanged(object sender, EventArgs e)
        {
            string da = txtdob.Text.ToString();
            DateTime dat = (Convert.ToDateTime(da.ToString()));
            DateTime now = DateTime.Now;
            int days = now.Subtract(dat).Days;
            int age = (days / 365);
            txtage.Text = age.ToString();
        }

        protected void txtreg_TextChanged(object sender, EventArgs e)
        {
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

           c = new connect();
            c.cnn.Close();
            c.cnn.Open();
            c.cmd.CommandText = "Select name,dob,age,pno,gender,addr from registration where regno='" + txtreg.Text + "'";
            rdr = c.cmd.ExecuteReader();
            bool temp = false;
            while (rdr.Read())
            {
                txtname.Text = Convert.ToString(rdr["name"]);
                txtdob.Text = rdr["dob"].ToString();
                txtage.Text = rdr["age"].ToString();
                txtMobile.Text = rdr["pno"].ToString();
                String gender = rdr["gender"].ToString();
                if (gender == "Male")
                    radiogender.SelectedValue = "1";
                else
                    radiogender.SelectedValue = "2";
                txtaddr.Text = rdr["addr"].ToString();
                temp = true;

            }
            if (temp == false)
            {
                Response.Write("<script>alert('Not Found')</alert>");
                c.cnn.Close();
            }
            rdr.Close();
            ds = new DataSet();
            adp = new SqlDataAdapter("Select * from registration", c.cnn);
            adp.Fill(ds, "Table2");
            c.cnn.Close();
        }
    }
}
    


