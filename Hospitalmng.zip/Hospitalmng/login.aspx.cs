﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.Windows.Forms;



namespace Hospitalmng
{
    public partial class login : System.Web.UI.Page

    {
        connect c;
        SqlDataAdapter adp = new SqlDataAdapter();
        DataSet ds = new DataSet();
        protected void Page_Load(object sender, EventArgs e)
        {

        }



        protected void btnsign_Click(object sender, EventArgs e)
        {
            try
            {


                c = new connect();
                c.cmd.CommandText = "Select * from logintable where username='" + txtuser.Text + "' and password='" + txtpass.Text + "'";
                ds = new DataSet();
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "log");
                if (ds.Tables["log"].Rows.Count > 0)
                {
                    MessageBox.Show("You have logged successfully");
                   
                    if (txtuser.Text == "staff")
                    {
                        Response.Redirect("home.aspx");
                    }
                    else if (txtuser.Text == "doctor")
                    {
                        Response.Redirect("dochome.aspx");
                        
                    }
                    else if(txtuser.Text=="admin")
                    {
                        Response.Redirect("adminhome.aspx");
                    }
                    txtpass.Text = " ";
                    txtuser.Text = " ";
                }

                else
                {
                    MessageBox.Show("incorrect password");
                    Response.Redirect("~/login.aspx");
                }
            }
            catch (Exception)
            {
               
            }
            finally
            {
                c.cnn.Close();
                txtuser.Text = "";
                txtpass.Text = "";
            }


        }




                
        }
    }
    
