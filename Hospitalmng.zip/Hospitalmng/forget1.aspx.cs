﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Hospitalmng
{
    public partial class forget1 : System.Web.UI.Page
    {
        connect c;
        SqlDataAdapter adp = new SqlDataAdapter();
        DataSet ds = new DataSet();

        protected void Page_Load(object sender, EventArgs e)
        {
            lblnew.Visible = false;
            lblconfrm.Visible = false;
            txtnewpass.Visible = false;
            txtcnfrm.Visible = false;
            btnsave.Visible = false;

        }

        protected void btnverify_Click1(object sender, EventArgs e)
        {
            try
            {
                c = new connect();
                c.cmd.CommandText = "select * from logintable where email='" + txtemail.Text + " ' ";
                adp.SelectCommand = c.cmd;
                adp.Fill(ds, "log");
                if (ds.Tables["log"].Rows.Count > 0)
                {

                    MessageBox.Show("Email verified");
                    lblnew.Visible = true;
                    lblconfrm.Visible = true;
                    txtnewpass.Visible = true;
                    txtcnfrm.Visible = true;
                    btnsave.Visible = true;
                }
                else
                {
                    MessageBox.Show("Invalid email Id");
                }
            }
            catch (Exception)
            { }
            finally
            {
                c.cnn.Close();
            }


        }

        protected void btnsave_Click(object sender, EventArgs e)
        {
            String newpass = txtnewpass.Text;
            String confirmpass = txtcnfrm.Text;
            if (newpass == confirmpass)
            {
                try
                {
                    c = new connect();
                    c.cmd.CommandText = "select * from logintable where username='" + txtus.Text + "'";
                    adp.SelectCommand = c.cmd;
                    adp.Fill(ds, "log");
                    if (ds.Tables["log"].Rows.Count > 0)
                    {
                        c.cmd.CommandText = "update logintable set password='" + newpass + "' where username ='" + txtus.Text + "'";
                        MessageBox.Show("Password Changed");
                        c.cmd.ExecuteNonQuery();
                    }
                    else
                    {
                        MessageBox.Show("invalid user");

                    }

                }


                catch (Exception) { }
                finally
                {
                    c.cnn.Close();
                }
            }

            else
            {
                MessageBox.Show("new password should be equal to confirm password");
            }
        }

        protected void txtbut_Click(object sender, EventArgs e)
        {
            Response.Redirect("login.aspx");
        }
    }
}

    

    
