﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace Hospitalmng
{
    public partial class adminpatient : System.Web.UI.Page
    {





        connect c;
        DataSet ds = new DataSet();
            protected void Page_Load(object sender, EventArgs e)
            {
            }
            protected void gvbind()
            {
                c = new connect();

                c.cnn.Close();
                c.cnn.Open();
                //  SqlCommand cmd = new SqlCommand("select * from registration", c.cnn);
                string query = "select * from inpatient";
                SqlDataAdapter adp = new SqlDataAdapter(query, c.cnn);
                DataTable dt = new DataTable();
                adp.Fill(dt);

                GridView1.DataSource = dt;
                GridView1.DataBind();


            }
            protected void gbind()
            {
                c = new connect();

                c.cnn.Close();
                c.cnn.Open();
                //  SqlCommand cmd = new SqlCommand("select * from registration", c.cnn);
                string query = "select * from outpatient";
                SqlDataAdapter adp = new SqlDataAdapter(query, c.cnn);
                DataTable dt = new DataTable();
                adp.Fill(dt);

                GridView2.DataSource = dt;
                GridView2.DataBind();


            }





            protected void btnin_Click(object sender, ImageClickEventArgs e)
            {
                gvbind();
            }

            protected void btnout_Click(object sender, ImageClickEventArgs e)
            {
                gbind();
            }
        }
    }
