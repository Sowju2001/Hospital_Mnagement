﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Hospitalmng
{
    public partial class register : System.Web.UI.Page
    {
        connect c;
        SqlDataAdapter adp = new SqlDataAdapter();
        DataSet ds = new DataSet();

        String id = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GenerateAutoId();
            }
            

        }
        private void GenerateAutoId()
        {
            c = new connect();
           
            c.cmd.CommandText="select count(regno) from registration";
            int i = Convert.ToInt32(c.cmd.ExecuteScalar());

            c.cnn.Close();
            i++;
            txtreg.Text = id + i.ToString();

        }



        protected void btnCancel_Click(object sender, EventArgs e)
        {
            txtreg.Text="";

            txtname.Text = " ";
            txtguard.Text = " ";
            txtdob.Text = " ";
            txtage.Text = " ";
            radiogender.ClearSelection();
            txtheight.Text = " ";
            txtweight.Text = " ";
            txtaddr.Text = " ";
            txtpt.Text = " ";
            txtcountry.Text = " ";
            txtMobile.Text = " ";
            txtstate.Text = " ";
            GenerateAutoId();
        }

        protected void Btnadd_Click(object sender, EventArgs e)
        {
            try
            {
                
                c = new connect();
                if (c.cnn.State == System.Data.ConnectionState.Closed)
                {
                    c.cnn.Open();

                }


                /* DateTime dt = DateTime.Now;
                 DateTime d = DateTime.txtdob.ToString () ;
                 txtage.Text = d -dt;*/


                txtreg.Enabled = false;
                        
                c.cmd.Parameters.Clear();
                c.cmd.CommandText="insert into registration values(@regno,@name,@fname,@dob,@age,@pno,@gender,@height,@weight,@addr,@patienttype,@state,@country)";
                c.cmd.Parameters.AddWithValue("@regno", Convert.ToDouble(txtreg.Text));
                c.cmd.Parameters.AddWithValue("@name", txtname.Text);
                c.cmd.Parameters.AddWithValue("@fname", txtguard.Text);
                c.cmd.Parameters.AddWithValue("@dob", Convert.ToDateTime(txtdob.Text));
                c.cmd.Parameters.AddWithValue("@age", Convert.ToDouble(txtage.Text));
                c.cmd.Parameters.AddWithValue("@pno", Convert.ToDouble(txtMobile.Text));
                c.cmd.Parameters.AddWithValue("@gender", radiogender.SelectedItem.Value.ToString());
                c.cmd.Parameters.AddWithValue("@height", txtheight.Text);
                c.cmd.Parameters.AddWithValue("@weight", txtweight.Text);
                c.cmd.Parameters.AddWithValue("@addr", txtaddr.Text);
                c.cmd.Parameters.AddWithValue("@patienttype", txtpt.Text);
                c.cmd.Parameters.AddWithValue("@state", txtstate.Text);
                c.cmd.Parameters.AddWithValue("@country", txtcountry.Text);
                c.cmd.ExecuteNonQuery();


                MessageBox.Show("Registered successfully......!");
                c.cnn.Close();

            }
            catch (Exception ex)
            {
                MessageBoxButtons btn = new MessageBoxButtons();
                MessageBox.Show(ex.ToString(), "", btn, MessageBoxIcon.Error);

            }
            finally
            {
                c.cnn.Close();
            }



        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            Response.Redirect("update.aspx");
        }

        protected void btnbck_Click(object sender, EventArgs e)
        {
            Response.Redirect("home.aspx");
        }

        protected void txtdob_TextChanged(object sender, EventArgs e)
        {
            string da = txtdob.Text.ToString();
            DateTime dat = (Convert.ToDateTime(da.ToString()));
            DateTime now = DateTime.Now;
            int days = now.Subtract(dat).Days;
            int age = (days / 365);
            txtage.Text = age.ToString();
        }
    }
}
